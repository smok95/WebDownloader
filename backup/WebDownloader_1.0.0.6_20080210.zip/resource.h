//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WebDownloader.rc
//
#define IDD_WEBDOWNLOADER_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_EDIT1                       1000
#define IDC_EDIT_FILEURL                1000
#define IDC_STATIC_ADDRESS              1001
#define IDC_PROGRESS                    1002
#define IDC_STATIC_PERCENT              1003
#define IDC_STATIC_FILENAME             1004
#define IDC_STATIC_DN_STATE             1005
#define IDC_STATIC_STATE_SPEED          1006
#define IDC_STATIC_CAPTION_FILE         1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
