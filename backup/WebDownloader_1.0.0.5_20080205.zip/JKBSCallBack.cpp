#include "StdAfx.h"
#include ".\jkbscallback.h"
#include "JKDebug.h"

CJKBSCallBack::CJKBSCallBack(void)
{
	SetProgressCtrl(NULL);	
	SetPercentTextWnd(NULL);
	m_bCancel = NULL;
}

CJKBSCallBack::~CJKBSCallBack(void)
{
	m_pPC = NULL;
}

HRESULT CJKBSCallBack::OnProgress(ULONG ulProgress, ULONG ulProgressMax, ULONG ulStatusCode, LPCWSTR szStatusText)
{	
	RLSW("%s : ulProgress:%d, ulProgressMax:%d, ulStatusCode:%d, statusText:%s",
		F, ulProgress, ulProgressMax, ulStatusCode, szStatusText);

	RLSW("%d",*m_bCancel);
	if(*m_bCancel)	return E_ABORT;
	
	float pos = 0;
	if(ulProgressMax>0)
	{
		pos = ((float)ulProgress/(float)ulProgressMax) *100;
		
	}
	if(m_pPC)
	{		
		m_pPC->SetPos((int)pos);
	}

	if(m_hPercentWnd)
	{
		char percent[20]={0,};
		wsprintf(percent, "%d %%",(int)pos);
		SetWindowText(m_hPercentWnd, percent);
	}

	return S_OK;
}
void CJKBSCallBack::SetProgressCtrl(CProgressCtrl* pPC)
{
	m_pPC = NULL;
	if(pPC)
		m_pPC = pPC;
}

void CJKBSCallBack::SetPercentTextWnd(HWND hWnd)
{
	m_hPercentWnd = NULL;
	if(hWnd)
		m_hPercentWnd = hWnd;
}

void CJKBSCallBack::SetCancelFlag(BOOL* bCancel){	m_bCancel = bCancel;	}
